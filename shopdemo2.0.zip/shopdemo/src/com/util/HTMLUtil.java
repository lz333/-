package com.util;

/**
 * HTML�������ɹ���
 * @author hahaha
 *
 */
public class HTMLUtil {
	public static String generateHtml(String title, String body) {
		StringBuilder sb=new StringBuilder();
		sb.append("<html><head><title>");
		sb.append(title);
		sb.append("</title></head>");
		sb.append("<body>");
		sb.append(body);
		sb.append("</body></html>");
		return sb.toString();
	}
}
