package com.user.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.entity.User;
import com.util.HTMLUtil;

public class IndexView extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {            
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		User user = (User) request.getSession().getAttribute("user");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String title = "Ӧ����ҳ";
		String body = "��ǰ��¼���û���"+user.getId()+
					"<br/>��¼ʱ�䣺"+sdf.format(user.getLogintime())+
					"<br><a href='IndexView'>��ҳ</a>"+
					"<br><a href='PersonalInfoView'>��������</a>"+
					"<br><a href=''>�ҵĹ��ﳵ</a>";
		String html = HTMLUtil.generateHtml(title, body);
		out.print(html);
	}

}
