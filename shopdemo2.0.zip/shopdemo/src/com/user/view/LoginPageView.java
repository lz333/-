package com.user.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.HTMLUtil;

public class LoginPageView extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
		
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		String error = (String) request.getAttribute("error");
		if(error!=null)
			out.print("�����µ�¼������<br/> ");
		String title = "��¼ҳ��";
		String body = "<form action='LoginServlet' method='post'>"+
						"�û�����<input type='text' name='id'/><br/>"+
						"���룺<input type='password' name='password'/><br/>"+
						"<input type='submit' value='��¼'/></form>";
		String html="";
		html = HTMLUtil.generateHtml(title, body);
		out.print(html);
		out.flush();
		out.close();
	}

}
