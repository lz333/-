package com.user.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.HTMLUtil;

public class AddInformation extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String id = (String)request.getSession().getAttribute("id");
		String zy = request.getParameter("zhuanye");
		String school = request.getParameter("school");
		String[] jishu = request.getParameterValues("jishu");
		out.println("����\t"+id+"<br/>");
		out.println("רҵ����\t"+zy+"<br/>");
		out.println("ѧУ����\t"+school+"<br/>");
		out.println("���ռ���\t");
		for(String i:jishu)
			out.println(i+"<br/>");
		String title = "������Ϣ";
		String body = "<a href='Mainpage.jsp'>������ҳ</a>";
		String html = HTMLUtil.generateHtml(title, body);
		out.print(html);
	}

}
