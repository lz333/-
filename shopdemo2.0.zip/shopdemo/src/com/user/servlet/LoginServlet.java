package com.user.servlet;

import java.io.IOException;
import java.util.Date;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.User;

public class LoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			this.doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		HttpSession session = request.getSession();
		session.setAttribute("id", id);
		if(id.equals("qq") && password.equals("123456")){
			request.getRequestDispatcher("Mainpage.jsp").forward(request, response);
		}else{
			request.setAttribute("error", "error");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}

}
