package com.entity;

public class PersonalInfo {
	private String name;
	private int age;
	private String school;
	private String major;
	private String technology;
	public PersonalInfo(String name, String school, String major,
			String technology) {
		super();
		this.name = name;
		this.school = school;
		this.major = major;
		this.technology = technology;
	}
	public PersonalInfo() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	
}
